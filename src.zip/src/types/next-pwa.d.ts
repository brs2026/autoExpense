declare module "next-pwa";
